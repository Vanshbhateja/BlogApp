package com.Vansh.blog.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Vansh.blog.payloads.UserDto;

@Service
public interface UserService {

	UserDto createUser(UserDto user);
	UserDto getUserById(Integer Id);
	List<UserDto> getAllUsers();
	void deleteUserById(Integer Id);
	UserDto updateUser(UserDto user, Integer Id);
	
	
}
