package com.Vansh.blog.exceptions;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResourceNotFoundException extends RuntimeException{
	
	String resourceName;
	String fieldname;
	long fieldValue;
	
	public ResourceNotFoundException(String rn, String fn, long fv) {
		super(String.format("%s not found wit %s : %s", rn,fn, fv));
		this.resourceName=rn;
		this.fieldname=fn;
		this.fieldValue=fv;
	}
	

}
