package com.Vansh.blog.services.impl;

import java.util.Collection;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Vansh.blog.entities.User;
import com.Vansh.blog.exceptions.ResourceNotFoundException;
import com.Vansh.blog.payloads.UserDto;
import com.Vansh.blog.repositories.UserRepo;
import com.Vansh.blog.services.UserService;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	UserDto userDto;
	
	//@Autowired
	//User user;

	@Override
	public UserDto createUser(UserDto user) {
		
		 User useR = new User();
		 useR = userDtoToUser(user);
	     User useR1 = userRepo.save(useR);
		  return userToUserDto(useR1);
	}

	@Override
	public UserDto getUserById(Integer Id) {
		  User useR1 = userRepo.findById(Id).orElseThrow(()-> new ResourceNotFoundException("User", "Id", Id));
		  UserDto user = new UserDto();
		  user.setAbout(useR1.getAbout());
		  user.setId(useR1.getId());
		  user.setName(useR1.getName());
		  user.setPassword(useR1.getPassword());
		  user.setEmail(useR1.getEmail());
		  return user;
	}

	@Override
	public List<UserDto> getAllUsers() {
		List<User> allUseRs = userRepo.findAll();
		List<UserDto> allUsers = allUseRs.stream().map(user-> this.userToUserDto(user)).collect(Collectors.toList());
		return allUsers;
	}

	@Override
	public void deleteUserById(Integer Id) {
		User user = userRepo.findById(Id).orElseThrow(()-> new ResourceNotFoundException("User", "Id", Id));
		userRepo.delete(user);

	}

	@Override
	public UserDto updateUser(UserDto user, Integer Id) {
		  User useR = userRepo.findById(Id).orElseThrow(()-> new ResourceNotFoundException("User", "Id", Id));
		  useR.setAbout(user.getAbout());
		  //useR.setId(user.getId());
		  useR.setName(user.getName());
		useR.setPassword(user.getPassword());
		  useR.setEmail(user.getEmail());
	
	    // User useR1 = userRepo.save(useR);
		  return userToUserDto(userRepo.save(useR));
	}
	
	public User userDtoToUser(UserDto user) {
		User useR = new User();
		
		useR.setId(user.getId());
		useR.setName(user.getName());
		useR.setEmail(user.getEmail());
		useR.setAbout(user.getAbout());
		useR.setPassword(user.getPassword());
		
		return useR;
		
		
		
	}
    public UserDto userToUserDto(User useR) {
     UserDto user = new UserDto();
		
		user.setId(useR.getId());
		user.setName(useR.getName());
		user.setEmail(useR.getEmail());
		user.setAbout(useR.getAbout());
		user.setPassword(useR.getPassword());
		
		return user;
		
	}

}
