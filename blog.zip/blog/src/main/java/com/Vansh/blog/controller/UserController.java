package com.Vansh.blog.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Vansh.blog.payloads.UserDto;
import com.Vansh.blog.services.impl.UserServiceImpl;

@RestController
@RequestMapping("/blog")
public class UserController {
	
	@Autowired
	private UserServiceImpl userService;
	
	@GetMapping("/User/{Id}")
	public ResponseEntity<UserDto> getUser(@PathVariable Integer Id){
		
		UserDto user = userService.getUserById(Id);
		return new ResponseEntity<>(user, HttpStatus.OK);
	}
	@GetMapping("/Users")
	public ResponseEntity<List<UserDto>> getAllUsers(){
		
		List<UserDto> users = userService.getAllUsers();
		return new ResponseEntity<>(users, HttpStatus.OK);
	}
	@PostMapping("/AddUser")
	public ResponseEntity<UserDto> createUser(@RequestBody UserDto userd){
		
		UserDto user = userService.createUser(userd);
		return new ResponseEntity<>(user, HttpStatus.OK);
	}
	@PutMapping("/UpdateUser/{Id}")
	public ResponseEntity<UserDto> updateUser(@RequestBody UserDto userd,@PathVariable Integer Id){
		
		UserDto user = userService.updateUser(userd, Id);
		return new ResponseEntity<>(user, HttpStatus.OK);
	}
	@DeleteMapping("/DeleteUser/{Id}")
	public ResponseEntity<UserDto> deleteUser(@PathVariable Integer Id){
		
		 userService.deleteUserById(Id);
		return new ResponseEntity<>( HttpStatus.OK);
	}

}
