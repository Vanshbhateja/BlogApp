package com.Vansh.blog.payloads;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class ApiResponse {
	
	
	private String Message;
	private boolean Status;
	public ApiResponse(String message, boolean status) {
		super();
		Message = message;
		Status = status;
	}
	@Override
	public String toString() {
		return "ApiResponse [Message=" + Message + ", Status=" + Status + "]";
	}
	
	


}
